
<div id="sidebar">
	<ul>

<?php 
if( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) { 
	$before = "<li><h2>Recent Projects</h2>\n";
	$after = "</li>\n";

	$num_to_show = 35;

	echo prologue_recent_projects( $num_to_show, $before, $after );
} // if dynamic_sidebar
?>

		<li class="credits">
			<p><a href="http://sixx.se/nextgen/wordpress-microblog-theme">SiXX Microblog theme</a><br />based on <a href="http://automattic.com/">Prologue</a></p>
		</li>
	</ul>
</div> <!-- // sidebar -->

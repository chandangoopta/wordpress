<?php get_sidebar( ); ?>

<div id="footer">
</div>

</div> <!-- // wrapper -->

<?php wp_footer(); ?>

</body>
</html>
